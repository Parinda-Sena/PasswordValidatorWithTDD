package lib;
public enum PasswordStrength {
    INVALID,
    WEAK,
    MEDIUM,
    STRONG
}